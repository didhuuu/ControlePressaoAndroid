package br.com.didhuuu.controlepressao;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.content.Context;
import android.print.PrintDocumentAdapter;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Imprimir relatório").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        return true;
    }
    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if ("Imprimir relatório".equals(item.getTitle())) {
            PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
            PrintDocumentAdapter adapter=web.createPrintDocumentAdapter("Relatorio de Pressao");
            pm.print("Relatorio de Pressao",adapter,new PrintAttributes.Builder().build());
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
