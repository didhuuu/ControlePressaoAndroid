# Controle de Pressão — Android

Projeto Android Studio (Java + WebView) com registro manual e relatório imprimível.
- Abrir a pasta no Android Studio.
- Usar JDK 17 e Android SDK Platform 35.
- Sincronizar Gradle e executar em dispositivo/emulador.
- Para gerar APK: Build > Build APK(s).

Os registros ficam em armazenamento local WebView (localStorage). Não há permissão de internet nem integração com aparelho de medição.
O relatório não contém média nem assinatura. A impressão usa o serviço de impressão Android.
